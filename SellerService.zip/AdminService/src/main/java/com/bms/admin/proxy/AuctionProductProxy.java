package com.bms.admin.proxy;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


public interface AuctionProductProxy {

}
