package com.bms.admin.enums;

public enum ProductStatus {
	Approved,Rejected
}
