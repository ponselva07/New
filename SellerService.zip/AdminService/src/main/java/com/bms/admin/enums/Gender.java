package com.bms.admin.enums;

public enum Gender {
	Male,Female
}
