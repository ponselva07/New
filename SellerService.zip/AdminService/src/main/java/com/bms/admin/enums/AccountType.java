package com.bms.admin.enums;

public enum AccountType {
	Seller,Bidder,Admin
}
