package com.bms.admin.service;

import java.text.SimpleDateFormat;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bms.admin.dto.Login;
import com.bms.admin.model.User;
import com.bms.admin.repository.EnrollmentRepository;

@Service
@Transactional
public class EnrollmentServiceImpl implements EnrollmentService{

	@Autowired
	EnrollmentRepository repository;
	
	SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");

	
	@Override
	public User registerAuctionUser(User user) {
		User userResult=repository.save(user);
		if(userResult != null)
			return userResult;
		else
			return null;
	}

	@Override
	public User loginAuctionUser(Login login) {
		return repository.find(login.getUserId(),login.getPassword());
	}

}
