package com.bms.admin.service;

import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bms.admin.model.Category;
import com.bms.admin.repository.CategoryRepository;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService{

	@Autowired
	CategoryRepository repository;
	
	@Override
	public Category createCatogory(String categoryName) {
		Category category=new Category();
		category.setCategoryName(categoryName);
		category.setCreatedOn(new Date());
		return repository.save(category);
	}

	@Override
	public Category updateCatogory(Category category) {
		category.setUpdatedOn(new Date());
		return repository.save(category);
	}

	@Override
	public void deleteCatogory(Category category) {
		repository.delete(category);;
	}

	@Override
	public List<Category> getCatogoryList() {
		return repository.findAll();
	}

	@Override
	public Category findByCategoryId(Long categoryId) {
		return repository.findByCategoryId(categoryId);
	}

}
