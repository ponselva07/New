package com.bms.admin.service;

import java.util.List;

import com.bms.admin.model.Category;

public interface CategoryService {
	public Category createCatogory(String categoryName);
	public Category updateCatogory(Category category);
	public void deleteCatogory(Category category);
	public List<Category> getCatogoryList();
	public Category findByCategoryId(Long categoryId);
}
