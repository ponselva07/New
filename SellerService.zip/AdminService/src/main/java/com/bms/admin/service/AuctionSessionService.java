package com.bms.admin.service;

import java.util.List;

import com.bms.admin.model.AuctionSession;

public interface AuctionSessionService {

	AuctionSession createSession(AuctionSession session);
	AuctionSession findBySessionId(Integer sessionId);
	AuctionSession updateSession(AuctionSession session);
	void deleteSession(AuctionSession session);
	List<AuctionSession> getSessionList();
}
