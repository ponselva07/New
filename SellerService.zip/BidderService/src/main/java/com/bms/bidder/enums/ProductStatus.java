package com.bms.bidder.enums;

public enum ProductStatus {
	Approved,Rejected
}
