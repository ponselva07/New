package com.bms.bidder.enums;

public enum Status {
	Active,Inactive
}
