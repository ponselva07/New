package com.bms.bidder.service;

import java.util.List;
import java.util.Map;

import com.bms.bidder.model.BiddingHistory;
import com.bms.bidder.model.Product;

public interface BidderService {
	List<Map<String,Product>> getProductListByCategory();
	BiddingHistory registerParticipation(Product product);
}
