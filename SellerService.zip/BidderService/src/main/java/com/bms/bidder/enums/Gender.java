package com.bms.bidder.enums;

public enum Gender {
	Male,Female
}
