package com.bms.bidder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BidderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BidderServiceApplication.class, args);
	}
}
