package com.bms.seller.enums;

public enum Gender {
	Male,Female
}
