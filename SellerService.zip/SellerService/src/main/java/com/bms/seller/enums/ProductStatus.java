package com.bms.seller.enums;

public enum ProductStatus {
	Approved,Rejected
}
