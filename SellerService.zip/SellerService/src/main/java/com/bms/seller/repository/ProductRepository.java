package com.bms.seller.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bms.seller.model.Product;

public interface ProductRepository extends JpaRepository<Product,Long>{
	Product findByProductId(Long productId);
	List<Product> findAllByProductId(Long sellerId);
}
