package com.bms.seller.enums;

public enum Status {
	Active,Inactive
}
