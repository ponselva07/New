package com.bms.seller.service;

import java.util.List;
import java.util.Map;

import com.bms.seller.model.Category;
import com.bms.seller.model.Product;
import com.bms.seller.model.User;


public interface SellerService {
	List<Category> getCatogoryList();
	Product submitProduct(Product product);
	List<Product> getProductList();
	List<User> getBidderList(Long productId);
	Product findByProductId(Long productId);
	Product updateProduct(Product product);
	void deleteCatogory(Product product);
	List<Product> getProductList(Long sellerId);
	List<Map<String,Product>> getProductListByCategory();
}
