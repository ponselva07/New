package com.bms.seller;

public interface SellerProxy {

}
