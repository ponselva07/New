package com.bms.seller.enums;

public enum AccountType {
	Seller,Bidder,Admin
}
