package com.bms.seller.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bms.seller.SellerProxy;
import com.bms.seller.model.Category;
import com.bms.seller.model.Product;
import com.bms.seller.model.User;
import com.bms.seller.repository.ProductRepository;

@Service
public class SellerServiceImpl implements SellerService {

	@Autowired
	ProductRepository productRepository;
	@Autowired
	SellerProxy proxy;
	@Override
	public List<Category> getCatogoryList() {
		return null;
	}
	@Override
	public Product submitProduct(Product product) {
		return productRepository.saveAndFlush(product);
	}
	@Override
	public List<Product> getProductList() {
		return null;
	}
	@Override
	public List<User> getBidderList(Long productId) {
		return null;
	}
	@Override
	public Product findByProductId(Long productId) {
		return productRepository.findByProductId(productId);
	}
	@Override
	public Product updateProduct(Product product) {
		return productRepository.save(product);
	}
	@Override
	public void deleteCatogory(Product product) {
		productRepository.delete(product);		
		
		
	}
	@Override
	public List<Product> getProductList(Long sellerId) {
		return productRepository.findAllByProductId(sellerId);
	}
	@Override
	public List<Map<String, Product>> getProductListByCategory() {
		return null;
	}

	

}
