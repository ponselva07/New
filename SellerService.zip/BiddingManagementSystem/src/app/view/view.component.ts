import { Component, OnInit, Inject } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface Product {
  productId: number;
  productName: string;
  productDetail: string;
}

const ELEMENT_DATA: Product[] = [
  {productId: 1,productName:'Lenova',productDetail:'Detail'},
  {productId: 2,productName:'Apple IPhone',productDetail:'Detail'}
];

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  productId: number;
  productName: string;
  productDetail: string;

  displayedColumns: any[] = ['productId', 'productName', 'productDetail'];
  columnsToDisplay: any[] = this.displayedColumns.slice();
  data = new MatTableDataSource(ELEMENT_DATA);
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  showDetail(): void {
    const dialogRef = this.dialog.open(ProductDialog, {
      width: '300px',
      data: {productId: this.productId, productName: this.productName,productDetail:this.productDetail}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  applyFilter(filterValue: string) {
    // Remove whitespace
    filterValue = filterValue.trim();
    // MatTableDataSource defaults to lowercase matches
    filterValue = filterValue.toLowerCase();
    this.data.filter = filterValue;
  }
}
@Component({
  selector: 'product-dialog',
  templateUrl: 'product-dialog.html',
})
export class ProductDialog {

  constructor(
    public dialogRef: MatDialogRef<ProductDialog>,
    @Inject(MAT_DIALOG_DATA) public data: Product) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
