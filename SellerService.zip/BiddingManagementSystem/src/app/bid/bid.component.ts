import { Component, OnInit, Inject } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface Bid {
  productName: string;
  productSeller: string;
  sessionEndTime: number;
}

const ELEMENT_DATA: Bid[] = [
  {productName:'Lenova',productSeller:'Ponselva',sessionEndTime:5.00},
  {productName:'Apple IPhone',productSeller:'Ponselva',sessionEndTime:5.00}
];

@Component({
  selector: 'app-bid',
  templateUrl: './bid.component.html',
  styleUrls: ['./bid.component.css']
})
export class BidComponent implements OnInit {

  productName: string;
  productSeller: string;
  sessionEndTime: number;

  displayedColumns: any[] = ['productName', 'productSeller', 'sessionEndTime'];
  columnsToDisplay: any[] = this.displayedColumns.slice();
  data = new MatTableDataSource(ELEMENT_DATA);
  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  showBid(): void {
    const dialogRef = this.dialog.open(BidDialog, {
      width: '300px',
      data: {productName: this.productName, productSeller: this.productSeller,sessionEndTime:this.sessionEndTime}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  applyFilter(filterValue: string) {
    // Remove whitespace
    filterValue = filterValue.trim();
    // MatTableDataSource defaults to lowercase matches
    filterValue = filterValue.toLowerCase();
    this.data.filter = filterValue;
  }
}

@Component({
  selector: 'bid-dialog',
  templateUrl: 'bid-dialog.html',
})
export class BidDialog {

  constructor(
    public dialogRef: MatDialogRef<BidDialog>,
    @Inject(MAT_DIALOG_DATA) public data: Bid) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}

