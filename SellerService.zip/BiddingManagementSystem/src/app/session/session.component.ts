import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';


export interface Session {
  sessionDate: Date;
  startTime: number;
  endTime: number;
  reserved: boolean;
}

const ELEMENT_DATA: Session[] = [
  {sessionDate: new Date(), startTime:1,endTime: 2, reserved:false},
  {sessionDate: new Date(), startTime:2,endTime: 3, reserved:true}
];
@Component({
  selector: 'app-session',
  templateUrl: './session.component.html',
  styleUrls: ['./session.component.css']
})
export class SessionComponent implements OnInit {

  displayedColumns: any[] = ['sessionDate', 'startTime', 'endTime','reserved'];
  columnsToDisplay: any[] = this.displayedColumns.slice();
  //data: Category[] = ELEMENT_DATA;
  data = new MatTableDataSource(ELEMENT_DATA);

  constructor() { }

  ngOnInit() {
  }

  approveProduct() {
  }

  rejectProduct(){
    
  }
  applyFilter(filterValue: string) {
    // Remove whitespace
    filterValue = filterValue.trim();
    // MatTableDataSource defaults to lowercase matches
    filterValue = filterValue.toLowerCase();
    this.data.filter = filterValue;
  }

}
