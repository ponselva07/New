
export class User{
    userId?:number;
    firstName:string;
    lastName:string;
    dob:Date;
    gender:string;
    email:string;
    phoneNumber:string;
    accountType:string;
    password:string;
    confirmPassword:string;
}