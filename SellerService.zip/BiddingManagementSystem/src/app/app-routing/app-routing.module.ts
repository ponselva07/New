import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { LoginComponent } from '../login/login.component';
import { RegistrationComponent } from '../registration/registration.component';
import { AdminComponent } from '../admin/admin.component';
import { SellerComponent } from '../seller/seller.component';
import { AdminLayoutComponent } from '../layout/admin-layout.component';
import { CategoryComponent } from 'src/app/category/category.component';
import { SessionComponent } from 'src/app/session/session.component';
import { BidderComponent } from 'src/app/bidder/bidder.component';
import { ItemComponent } from 'src/app/item/item.component';
import { SellerLayoutComponent } from '../layout/seller-layout.component';
import { ProductComponent } from 'src/app/product/product.component';
import { ViewComponent } from 'src/app/view/view.component';
import { BidderLayoutComponent } from 'src/app/layout/bidder-layout.component';
import { BidComponent } from 'src/app/bid/bid.component';

const appRoutes:Routes = [
  {path:'login',component:LoginComponent},
  {
    path: 'admin', component: AdminLayoutComponent,
    children: [
      {path:'category',component:CategoryComponent},
      {path:'item',component:ItemComponent},
      {path:'session',component:SessionComponent},
      {path:'login',redirectTo:'/login',pathMatch:'full'}
    ]
  },
  {
    path: 'seller', component: SellerLayoutComponent,
    children: [
      {path:'product',component:ProductComponent},
      {path:'view',component:ViewComponent},
      {path:'login',redirectTo:'/login',pathMatch:'full'}
    ]
  },
  {
    path: 'bidder', component: BidderLayoutComponent,
    children: [
      {path:'bid',component:BidComponent},
      {path:'view',component:ViewComponent},
      {path:'login',redirectTo:'/login',pathMatch:'full'}
    ]
  },
  {path:'register',component:RegistrationComponent},
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports:[
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
