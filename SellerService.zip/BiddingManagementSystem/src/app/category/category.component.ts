import { Component, OnInit, Inject } from '@angular/core';
import { MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface Category {
  categoryId: number;
  categoryName: string;
  admin: string;
}

const ELEMENT_DATA: Category[] = [
  {categoryId: 1, categoryName: 'Laptop', admin:"Admin"},
  {categoryId: 2, categoryName: 'Mobiles', admin:"Admin"}
];


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  categoryId: number;
  categoryName: string;
  admin: string;

  displayedColumns: any[] = ['categoryId', 'categoryName', 'admin'];
  columnsToDisplay: any[] = this.displayedColumns.slice();
  //data: Category[] = ELEMENT_DATA;
  data = new MatTableDataSource(ELEMENT_DATA);

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }

  addCategory(): void {
    const dialogRef = this.dialog.open(CategoryDialog, {
      width: '450px',
      data: {categoryId: this.categoryId, categoryName: this.categoryName,admin:this.admin}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  editCategory(){
    
  }

  removeCategory() {
  }

  applyFilter(filterValue: string) {
    // Remove whitespace
    filterValue = filterValue.trim();
    // MatTableDataSource defaults to lowercase matches
    filterValue = filterValue.toLowerCase();
    this.data.filter = filterValue;
  }
}

@Component({
  selector: 'category-dialog',
  templateUrl: 'category-dialog.html',
})
export class CategoryDialog {

  constructor(
    public dialogRef: MatDialogRef<CategoryDialog>,
    @Inject(MAT_DIALOG_DATA) public data: Category) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

}