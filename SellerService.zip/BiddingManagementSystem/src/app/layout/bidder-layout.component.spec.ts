import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BidderLayoutComponent } from './bidder-layout.component';

describe('BidderLayoutComponent', () => {
  let component: BidderLayoutComponent;
  let fixture: ComponentFixture<BidderLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BidderLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BidderLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
