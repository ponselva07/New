import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidder-layout',
  templateUrl: './bidder-layout.component.html',
  styleUrls: ['./bidder-layout.component.css']
})
export class BidderLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
