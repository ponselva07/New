import {NgModule} from "@angular/core";
import { CommonModule } from '@angular/common';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {CdkTableModule} from '@angular/cdk/table';
import {CdkTreeModule} from '@angular/cdk/tree';
import {
  MatAutocompleteModule,MatBadgeModule,MatBottomSheetModule,MatButtonModule,
  MatButtonToggleModule,MatCardModule,MatCheckboxModule,MatChipsModule,MatStepperModule,
  MatDatepickerModule,MatDialogModule,MatDividerModule,MatExpansionModule,MatGridListModule,
  MatIconModule,MatInputModule,MatListModule,MatMenuModule,MatNativeDateModule,MatPaginatorModule,
  MatProgressBarModule,MatProgressSpinnerModule,MatRadioModule,MatRippleModule,MatSelectModule,
  MatSidenavModule,MatSliderModule,MatSlideToggleModule,MatSnackBarModule,MatSortModule,
  MatTableModule,MatTabsModule,MatToolbarModule,MatTooltipModule,MatTreeModule
} from '@angular/material';

@NgModule({
  imports: [
    CommonModule,MatAutocompleteModule,MatBadgeModule,MatBottomSheetModule,MatButtonModule,
    MatButtonToggleModule,MatCardModule,MatCheckboxModule,MatChipsModule,MatStepperModule,
    MatDatepickerModule,MatDialogModule,MatDividerModule,MatExpansionModule,MatGridListModule,
    MatIconModule,MatInputModule,MatListModule,MatMenuModule,MatNativeDateModule,MatPaginatorModule,
    MatProgressBarModule,MatProgressSpinnerModule,MatRadioModule,MatRippleModule,MatSelectModule,
    MatSidenavModule,MatSliderModule,MatSlideToggleModule,MatSnackBarModule,MatSortModule,
    MatTableModule,MatTabsModule,MatToolbarModule,MatTooltipModule,MatTreeModule],
  exports: [
    CommonModule,MatAutocompleteModule,MatBadgeModule,MatBottomSheetModule,MatButtonModule,
    MatButtonToggleModule,MatCardModule,MatCheckboxModule,MatChipsModule,MatStepperModule,
    MatDatepickerModule,MatDialogModule,MatDividerModule,MatExpansionModule,MatGridListModule,
    MatIconModule,MatInputModule,MatListModule,MatMenuModule,MatNativeDateModule,MatPaginatorModule,
    MatProgressBarModule,MatProgressSpinnerModule,MatRadioModule,MatRippleModule,MatSelectModule,
    MatSidenavModule,MatSliderModule,MatSlideToggleModule,MatSnackBarModule,MatSortModule,
    MatTableModule,MatTabsModule,MatToolbarModule,MatTooltipModule,MatTreeModule,
    CdkTableModule,CdkTreeModule,DragDropModule,ScrollingModule
  ],
})
export class CustomMaterialModule { }
