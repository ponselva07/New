import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';

export interface Product {
  productId: number;
  productName: string;
  categoryName: string;
  sellerName: string;
  mimimumPrice: number;
  sessionStartTime:number;
}

const ELEMENT_DATA: Product[] = [
  {productId: 1, productName:'Lenova',categoryName: 'Laptop', sellerName:'ponselva',mimimumPrice:45000,sessionStartTime:1},
  {productId: 2, productName:'Sony LED',categoryName: 'TVs', sellerName:'ponselva',mimimumPrice:90000,sessionStartTime:2}
];

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  displayedColumns: any[] = ['productId', 'productName', 'categoryName','sellerName','minimumPrice','sessionStartTime'];
  columnsToDisplay: any[] = this.displayedColumns.slice();
  //data: Category[] = ELEMENT_DATA;
  data = new MatTableDataSource(ELEMENT_DATA);

  constructor() { }

  ngOnInit() {
  }

  approveProduct() {
  }

  rejectProduct(){
    
  }
  applyFilter(filterValue: string) {
    // Remove whitespace
    filterValue = filterValue.trim();
    // MatTableDataSource defaults to lowercase matches
    filterValue = filterValue.toLowerCase();
    this.data.filter = filterValue;
  }

}
