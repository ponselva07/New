import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  placeHolder="Enter the password as \'pwd123\'";
  constructor( private route: ActivatedRoute,private router:Router,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
    const userName=this.loginForm.controls['userName'].value;
    const password=this.loginForm.controls['password'].value;
    if (this.loginForm.invalid) {
        return;
    }
    if(password != 'pwd123'){
      return;
    }
    this.loading = true;
    this.router.navigate(['/admin']);
 }
}
