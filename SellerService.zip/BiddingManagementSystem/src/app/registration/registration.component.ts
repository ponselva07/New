import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from '../services/alert.service';
import { RegistrationService } from '../services/registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registerForm: FormGroup;
  loading = false;
  submitted = false;
  
  constructor(private route: ActivatedRoute,private router:Router,private alertService: AlertService,
    private registratiionService:RegistrationService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      dob:['',Validators.required],
      gender:[''],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber:['',Validators.required],
      accountType:['',Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword:['',Validators.required]
  },{validator:[this.dateValidation()]});
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  dateValidation() {
    return (group: FormGroup): {[key: string]: any} => {
      let tempDob = group.controls["dob"];
      let dob;
      if (!tempDob.value) {
        return {
          dob: "Date of birth is required"
        };
      }
      return {};
    }
  }
  onAccountTypeChange(event:Event){
    let selectedOptions = event.target['options'];
    let selectedIndex = selectedOptions.selectedIndex;
    let selectElementText = selectedOptions[selectedIndex].text;
    this.f.accountType.setValue(selectElementText);
  }
  onSubmit(){
        this.submitted = true;
        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        console.log("********************");
        console.log(this.registerForm.value);
        this.registratiionService.register(this.registerForm.value)
        .subscribe(
            data => {
                this.alertService.success('Registration successful', true);
                this.router.navigate(['/login']);
            },
            error => {
                console.log(error);
                this.alertService.error(error);
                this.loading = false;
            });

  }

}
