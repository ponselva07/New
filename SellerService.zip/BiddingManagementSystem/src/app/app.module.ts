import { NgtUniversalModule } from '@ng-toolkit/universal';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LoginComponent } from './login/login.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { RegistrationComponent } from './registration/registration.component';
import { SellerComponent } from './seller/seller.component';
import { BidderComponent } from './bidder/bidder.component';
import { AdminComponent } from './admin/admin.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SessionComponent } from './session/session.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CustomMaterialModule } from './custom-material/custom-material.module';
import { CommonModule } from '@angular/common';
import { AdminLayoutComponent } from './layout/admin-layout.component';
import { CategoryComponent, CategoryDialog } from './category/category.component';
import { ItemComponent } from './item/item.component';
import { SellerLayoutComponent } from './layout/seller-layout.component';
import { ProductComponent } from './product/product.component';
import { ViewComponent, ProductDialog } from './view/view.component';
import { BidderLayoutComponent } from './layout/bidder-layout.component';
import { BidComponent } from './bid/bid.component';

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    LoginComponent,
    RegistrationComponent,
    SellerComponent,
    BidderComponent,
    AdminComponent,
    SessionComponent,
    AdminLayoutComponent,
    CategoryComponent,
    ItemComponent,
    CategoryDialog,
    SellerLayoutComponent,
    ProductComponent,
    ViewComponent,
    BidderLayoutComponent,
    BidComponent,
    ProductDialog
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CustomMaterialModule,
    CommonModule,
    NgtUniversalModule
  ],
  entryComponents: [CategoryComponent, CategoryDialog],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
