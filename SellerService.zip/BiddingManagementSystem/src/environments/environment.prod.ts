export const environment = {
  production: true,
  adminService:"http://localhost:9001/auction"
};
